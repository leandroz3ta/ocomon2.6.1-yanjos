<?php
//carrega as configurações iniciais
include_once("../../resources/config/geral.php");

?>

<!DOCTYPE html>
<html>
	<head>
		<?php
			//carrega as configurações iniciais
			include("../geral/head.php");			
		?>
	</head>
	<body class="bg-red">
	
		<?php
			//carrega as configurações iniciais
			include("../geral/body.php");			
		?>
		<div class="body body-s">		
			<form action="" id="sky-form" class="sky-form">
			<header>Configuracoes gerais</header>
			
			<fieldset>					
				<section>
					<div class="row">
						<label class="label col col-4">Problema</label>
						<div class="col col-8">
							<label class="input">								
								<input type="text" name="problema">
							</label>
						</div>
					</div>
				</section>
				
				<section>
					<div class="row">
						<label class="label col col-4">Problema</label>
						<div class="col col-8">
							<label class="input">								
								<input type="text" name="problema">
							</label>
						</div>
					</div>
				</section>
				
				<section>
					<div class="row">
						<label class="label col col-4">Problema</label>
						<div class="col col-8">
							<label class="input">								
								<input type="text" name="problema">
							</label>
						</div>
					</div>
				</section>
				
				<section>
					<div class="row">
						<label class="label col col-4">Problema</label>
						<div class="col col-8">
							<label class="input">								
								<input type="text" name="problema">
							</label>
						</div>
					</div>
				</section>
				
				<section>
					<div class="row">
						<label class="label col col-4">Problema</label>
						<div class="col col-8">
							<label class="input">								
								<input type="text" name="problema">
							</label>
						</div>
					</div>
				</section>
				
				<section>
					<div class="row">
						<label class="label col col-4">Problema</label>
						<div class="col col-8">
							<label class="input">								
								<input type="text" name="problema">
							</label>
						</div>
					</div>
				</section>
				
				<section>
					<div class="row">
						<label class="label col col-4">Problema</label>
						<div class="col col-8">
							<label class="input">								
								<input type="text" name="problema">
							</label>
						</div>
					</div>
				</section>
				
				<section>
					<div class="row">
						<label class="label col col-4">Problema</label>
						<div class="col col-8">
							<label class="input">								
								<input type="text" name="problema">
							</label>
						</div>
					</div>
				</section>
				
				<section>
					<div class="row">
						<label class="label col col-4">Problema</label>
						<div class="col col-8">
							<label class="input">								
								<input type="text" name="problema">
							</label>
						</div>
					</div>
				</section>
				
				<section>
					<div class="row">
						<label class="label col col-4">Problema</label>
						<div class="col col-8">
							<label class="input">								
								<input type="text" name="problema">
							</label>
						</div>
					</div>
				</section>
				
				<section>
					<div class="row">
						<label class="label col col-4">Problema</label>
						<div class="col col-8">
							<label class="input">								
								<input type="text" name="problema">
							</label>
						</div>
					</div>
				</section>
				
				<section>
					<div class="row">
						<label class="label col col-4">Problema</label>
						<div class="col col-8">
							<label class="select">
								<select name="interested">
									<option value="none" selected disabled>Interested in</option>
									<option value="design">design</option>
									<option value="development">development</option>
									<option value="illustration">illustration</option>
									<option value="branding">branding</option>
									<option value="video">video</option>
								</select>
								<i></i>
							</label>
						</div>
					</div>							
				</section>
				
				<section>
					<div class="row">
						<label class="label col col-4">Problema</label>
						<div class="col col-8">
							<label class="select">
								<select name="interested">
									<option value="none" selected disabled>Interested in</option>
									<option value="design">design</option>
									<option value="development">development</option>
									<option value="illustration">illustration</option>
									<option value="branding">branding</option>
									<option value="video">video</option>
								</select>
								<i></i>
							</label>
						</div>
					</div>							
				</section>
				
				<section>
					<div class="row">
						<label class="label col col-4">Problema</label>
						<div class="col col-8">
							<label class="select">
								<select name="interested">
									<option value="none" selected disabled>Interested in</option>
									<option value="design">design</option>
									<option value="development">development</option>
									<option value="illustration">illustration</option>
									<option value="branding">branding</option>
									<option value="video">video</option>
								</select>
								<i></i>
							</label>
						</div>
					</div>							
				</section>
				
				<section>
					<div class="row">
						<label class="label col col-4">Problema</label>
						<div class="col col-8">
							<label class="select">
								<select name="interested">
									<option value="none" selected disabled>Interested in</option>
									<option value="design">design</option>
									<option value="development">development</option>
									<option value="illustration">illustration</option>
									<option value="branding">branding</option>
									<option value="video">video</option>
								</select>
								<i></i>
							</label>
						</div>
					</div>							
				</section>
				
				<section>
					<div class="row">
						<label class="label col col-4">Problema</label>
						<div class="col col-8">
							<label class="select">
								<select name="interested">
									<option value="none" selected disabled>Interested in</option>
									<option value="design">design</option>
									<option value="development">development</option>
									<option value="illustration">illustration</option>
									<option value="branding">branding</option>
									<option value="video">video</option>
								</select>
								<i></i>
							</label>
						</div>
					</div>							
				</section>
				
				<section>
						<div class="row">
							<div class="col col-4"></div>
							<div class="col col-8">
								<label class="checkbox"><input type="checkbox" name="remember" checked><i></i>Keep me logged in</label>
							</div>
						</div>
				</section>
				
				<section>
						<div class="row">
							<div class="col col-4"></div>
							<div class="col col-8">
								<label class="checkbox"><input type="checkbox" name="remember" checked><i></i>Keep me logged in</label>
							</div>
						</div>
				</section>
				
				<section>
						<div class="row">
							<div class="col col-4"></div>
							<div class="col col-8">
								<label class="checkbox"><input type="checkbox" name="remember" checked><i></i>Keep me logged in</label>
							</div>
						</div>
				</section>
				
				<section>
						<div class="row">
							<div class="col col-4"></div>
							<div class="col col-8">
								<label class="checkbox"><input type="checkbox" name="remember" checked><i></i>Keep me logged in</label>
							</div>
						</div>
				</section>
				
				<section>
						<div class="row">
							<div class="col col-4"></div>
							<div class="col col-8">
								<label class="checkbox"><input type="checkbox" name="remember" checked><i></i>Keep me logged in</label>
							</div>
						</div>
				</section>
				
				<section>
						<div class="row">
							<div class="col col-4"></div>
							<div class="col col-8">
								<label class="checkbox"><input type="checkbox" name="remember" checked><i></i>Keep me logged in</label>
							</div>
						</div>
				</section>
				
				<section>
						<div class="row">
							<div class="col col-4"></div>
							<div class="col col-8">
								<label class="checkbox"><input type="checkbox" name="remember" checked><i></i>Keep me logged in</label>
							</div>
						</div>
				</section>
				
				<section>
						<div class="row">
							<div class="col col-4"></div>
							<div class="col col-8">
								<label class="checkbox"><input type="checkbox" name="remember" checked><i></i>Keep me logged in</label>
							</div>
						</div>
				</section>
				
				<section>
						<div class="row">
							<div class="col col-4"></div>
							<div class="col col-8">
								<label class="checkbox"><input type="checkbox" name="remember" checked><i></i>Keep me logged in</label>
							</div>
						</div>
				</section>
				
				<section>
						<div class="row">
							<div class="col col-4"></div>
							<div class="col col-8">
								<label class="checkbox"><input type="checkbox" name="remember" checked><i></i>Keep me logged in</label>
							</div>
						</div>
				</section>
				
				<section>
						<div class="row">
							<div class="col col-4"></div>
							<div class="col col-8">
								<label class="checkbox"><input type="checkbox" name="remember" checked><i></i>Keep me logged in</label>
							</div>
						</div>
				</section>
				
				<section>
						<div class="row">
							<div class="col col-4"></div>
							<div class="col col-8">
								<label class="checkbox"><input type="checkbox" name="remember" checked><i></i>Keep me logged in</label>
							</div>
						</div>
				</section>
				
				<section>
						<div class="row">
							<div class="col col-4"></div>
							<div class="col col-8">
								<label class="checkbox"><input type="checkbox" name="remember" checked><i></i>Keep me logged in</label>
							</div>
						</div>
				</section>
				
				<section>
						<div class="row">
							<div class="col col-4"></div>
							<div class="col col-8">
								<label class="checkbox"><input type="checkbox" name="remember" checked><i></i>Keep me logged in</label>
							</div>
						</div>
				</section>
					
					
				
			</fieldset>
			<footer>
				<button type="submit" class="button">Cadastrar</button>
				<a href="#" class="button button-secondary modal-closer">Fechar</a>
			</footer>				
			</form>
		</div>
	
	</body>
</html>