

		<link rel="stylesheet" href="<?php echo $pathCSS;?>forms/demo.css">
		<link rel="stylesheet" href="<?php echo $pathCSS;?>forms/font-awesome.css">
		<link rel="stylesheet" href="<?php echo $pathCSS;?>forms/sky-forms.css">
		<!--[if lt IE 9]>
			<link rel="stylesheet" href="<?php echo $pathCSS;?>forms/sky-forms-ie8.css">
		<![endif]-->