		
	<link rel="stylesheet" type="text/css" href="<?php echo $pathCSS;?>dataTable/jquery.dataTables.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $pathCSS;?>dataTable/shCore.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $pathCSS;?>dataTable/demo.css">
	<style type="text/css" class="init">
	
td.details-control {
	background: url('<?php echo $pathIMG;?>dataTable/details_open.png') no-repeat center center;
	cursor: pointer;
	width: 10px !important;
}
tr.details td.details-control {
	background: url('<?php echo $pathIMG;?>dataTable/details_close.png') no-repeat center center;
	width: 10px !important;
}

	</style>