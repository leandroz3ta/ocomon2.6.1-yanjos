<?php
/* 
Configurações gerais para todas as paginas

*/

//inclui arquivo com o caminho dos arquivos
include("PATHS.php");

//define a liguagem padrão do sistema
define ( "LANGUAGE", "pt_BR.php");

//carrega arquivo de idioma
include($includeLANGUAGE.LANGUAGE);

session_start();
?>