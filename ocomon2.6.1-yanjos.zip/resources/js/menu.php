		
	<script type="text/javascript" src="<?php echo $pathJS;?>menu/jquery.1.10.2.min.js"></script>
	<script type="text/javascript" src="<?php echo $pathJS;?>menu/gnmenu.js"></script>