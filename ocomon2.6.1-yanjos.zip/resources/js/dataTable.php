		
	<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.12.3.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="<?php echo $pathJS;?>dataTable/jquery.dataTables.js">
	</script>
	<script type="text/javascript" language="javascript" src="<?php echo $pathJS;?>dataTable/shCore.js">
	</script>
	<script type="text/javascript" language="javascript" src="<?php echo $pathJS;?>dataTable/demo.js">
	</script>