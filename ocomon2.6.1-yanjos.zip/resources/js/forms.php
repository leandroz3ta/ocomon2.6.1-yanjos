		<script src="<?php echo $pathJS;?>forms/jquery.min.js"></script>
		<script src="<?php echo $pathJS;?>forms/jquery.form.min.js"></script>
		<script src="<?php echo $pathJS;?>forms/jquery.validate.min.js"></script>
		<script src="<?php echo $pathJS;?>forms/jquery.modal.js"></script>
		<script src="<?php echo $pathJS;?>forms/jquery-ui.min.js"></script>
		<!--[if lt IE 10]>
			<script src="<?php echo $pathJS;?>forms/jquery.placeholder.min.js"></script>
		<![endif]-->		
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="<?php echo $pathJS;?>forms/sky-forms-ie8.js"></script>
		<![endif]-->